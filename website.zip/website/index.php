<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
<title>This is the simple website</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="NEW WEBSITE" name="keywords">
    <meta content="NEW WBSITE"  name="description">
        <!-- Font Awesome -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet"> 
         <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.css" rel="stylesheet">
<!-- Google Web Fonts -->
<link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 
</head>
<body>
    <!-- top-bar-start-->
    <div class="container-fluid">
        <div class="row">
            <div class="col">
            <h1 class="m-2"><span class="text-primary">E</span>COURSES</h1>
</div>
<div class="col text-left">
<div class="d-inline-flex">
<i class="m-3 fa fa-2x fa-map-marker-alt text-primary "></i>
<div class="text-left">
<h6 class="m-3 font-weight-semi-bold ">Our Office</h6>
 <small>123 Street, New York, USA</small>
</div>
</div>
</div>
<div class="col text-left">
<div class="d-inline-flex">
<i class="m-3 fa fa-2x fa-envelope text-primary mr-9"></i>
<div class="text-left">
<h6 class="m-3 font-weight-semi-bold mb-1">Our Office</h6>
 <small>123 Street, New York, USA</small>
</div>
</div>
</div>
<div class="col text-left">
<div class="d-inline-flex">
<i class="m-3 fa fa-2x fa-phone text-primary mr-3"></i>
<div class="text-left">
<h6 class="m-3 font-weight-semi-bold mb-1">Call US</h6>
 <small>+012 345 6789</small>
</div>
</div>
</div>
 <!-- Topbar End -->
  <!-- Navbar start -->
  <div class="container-fluid">
  <div class="row border-top  m-4 ">
  <a class="d-flex bg-secondary  text-decoration-none"  >
  <h5 class="m-4 text-secondary"><i class="text-secondary fa fa-book-open mr-2"></i>Subjects</h5>
  <i class="fa fa-angle-down text-secondary m-4 "></i>
</a>
<nav class="collapse position-absolute navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0 bg-light" id="navbar-vertical" style="width: calc(100% - 30px); z-index: 9;">
                    <div class="navbar-nav w-100">
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link" data-toggle="dropdown">Web Design <i class="fa fa-angle-down float-right mt-1"></i></a>
                            <div class="dropdown-menu position-absolute bg-secondary border-0 rounded-0 w-100 m-0">
                                <a href="" class="dropdown-item">HTML</a>
                                <a href="" class="dropdown-item">CSS</a>
                                <a href="" class="dropdown-item">jQuery</a>
                            </div>
                        </div>
                        <a href="" class="nav-item nav-link">Apps Design</a>
                        <a href="" class="nav-item nav-link">Marketing</a>
                        <a href="" class="nav-item nav-link">Research</a>
                        <a href="" class="nav-item nav-link">SEO</a>
                    </div>
                </nav>
                <div class="col-lg-9 m-4">
                <nav class="navbar-expand-lg">
                    
                   
                    <div class=" navbar-collapse">
                        <div class="navbar-nav py-0">
                            <a href="index.html" class="nav-item nav-link active">Home</a>
                            <a href="about.html" class="nav-item nav-link">About</a>
                            <a href="course.html" class="nav-item nav-link">Courses</a>
                            <a href="teacher.html" class="nav-item nav-link">Teachers</a>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Blog</a>
                                <div class="dropdown-menu rounded-0 m-0">
                                    <a href="blog.html" class="dropdown-item">Blog List</a>
                                    <a href="single.html" class="dropdown-item">Blog Detail</a>
                                </div>
                            </div>
                            <a href="contact.html" class="nav-item nav-link">Contact</a>
                        </div>
                        <a class="btn btn-primary  ml-auto" href="">Join Now</a>
                    </div>
                </nav>
            </div>
</div>

</div>
<!--Navbar end-->


    <!-- Carousel Start -->
    <div class="container-fluid">
        <div id="header-carousel" class="carousel slide carousel-fade" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#header-carousel" data-slide-to="0" class="active"></li>
                <li data-target="#header-carousel" data-slide-to="1"></li>
                <li data-target="#header-carousel" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="position-relative " src="images/carousel-1.jpg" >
                    <div class="carousel-caption d-flex align-items-center justify-content-center">
                        <div class="p-1">
                            <h5 class=" text-uppercase "style="color: white">Best Online Courses</h5>
                            <h1 class="display-3 ">Best Education From Your Home</h1>
                            <a href="" class="btn btn-primary  mt-5">Learn More</a>
                        </div>
                    </div>
                </div>
                <div class="carousel-item" >
                    <img class="position-relative" src="images/carousel-2.jpg">
                    <div class="carousel-caption d-flex align-items-center justify-content-center">
                        <div class="p-1">
                            <h5 class=" text-uppercase">Best Online Courses</h5>
                            <h1 class="display-3 ">Best Online Learning Platform</h1>
                            <a href="" class="btn btn-primary mt-5">Learn More</a>
                        </div>
                    </div>
                </div>
                <div class="carousel-item" >
                    <img class="position-relative" src="images/carousel-3.jpg" >
                    <div class="carousel-caption d-flex align-items-center justify-content-center">
                        <div class="p-1">
                            <h5 class=" text-uppercase">Best Online Courses</h5>
                            <h1 class="display-3 ">New Way To Learn From Home</h1>
                            <a href="" class="btn btn-primary mt-5">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Carousel End -->

     <!-- About Start -->
     <div class="container-fluid m-3">
        <div class="container">
            <div class="row ">
                <div class="col">
                    <img class="img-fluid" src="images/about.jpg" alt="">
                </div>
                <div class="col">
                    <div class="text-left ">
                        <h5 class="text-primary text-uppercase">About Us</h5>
                        <h1>Innovative Way To Learn</h1>
                    </div>
                    <p>Aliquyam accusam clita nonumy ipsum sit sea clita ipsum clita, ipsum dolores amet voluptua duo dolores et sit ipsum rebum, sadipscing et erat eirmod diam kasd labore clita est. Diam sanctus gubergren sit rebum clita amet, sea est sea vero sed et. Sadipscing labore tempor at sit dolor clita consetetur diam. Diam ut diam tempor no et, lorem dolore invidunt no nonumy stet ea labore, dolor justo et sit gubergren diam sed sed no ipsum. Sit tempor ut nonumy elitr dolores justo aliquyam ipsum stet</p>
                    <a href="" class="btn btn-primary  mt-0">Learn More</a>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->
    
    <!-- Category Start -->
    <div class="container-fluid ">
        <div class="container ">
            <div class="text-center ">
                <h5 class="text-primary text-uppercase mb-3" style="letter-spacing: 5px;">Subjects</h5>
                <h1>Explore Top Subjects</h1>
            </div>
            <div class="row">
                <div class="col">
                    <div class="cat-item position-relative ">
                        <img class="img-fluid" src="images/cat-1.jpg" alt="">
                        <a class="cat-overlay text-white text-decoration-none" href="">
                            <h4 class=" m-5 font-weight-medium">Web Design</h4>
                            <h7 class="m-5 font-weight-medium">100 Course</h7>
</a>
                    </div>
                </div>
                <div class="col">
                    <div class="cat-item position-relative">
                        <img class="img-fluid" src="images/cat-2.jpg" alt="">
                        <a class="cat-overlay text-white text-decoration-none" href="">
                            <h4 class="m-5 font-weight-medium">Development</h4>
                            <h7 class="m-5 font-weight-medium">100 Course</h7>
</a>
                    </div>
                </div>
                <div class="col">
                    <div class="cat-item position-relative">
                        <img class="img-fluid" src="images/cat-3.jpg" alt="">
                        <a class="cat-overlay text-white text-decoration-none" href="">
                            <h4 class="m-5 font-weight-medium">Game Design</h4>
                            <h7 class="m-5 font-weight-medium">100 Course</h7>
</a>
                    </div>
                </div>
                <div class="col">
                    <div class="cat-item position-relative">
                        <img class="img-fluid" src="images/cat-4.jpg" alt="">
                        <a class="cat-overlay text-white text-decoration-none" href="">
                            <h4 class="m-5 font-weight-medium">Apps Design</h4>
                            <h7 class="m-5 font-weight-medium">100 Course</h7>
</a>
                    </div>
                </div>
                <div class="col">
                    <div class="cat-item position-relative ">
                        <img class="img-fluid" src="images/cat-5.jpg" alt="">
                        <a class="cat-overlay text-white text-decoration-none" href="">
                            <h4 class="m-5 font-weight-medium">Marketing</h4>
                            <h7 class="m-5 font-weight-medium">100 Course</h7>
</a>
                    </div>
                </div>
               
                
               
            </div>
        </div>
    </div>
    <!-- Category End -->